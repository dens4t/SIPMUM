<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DokumentasiUnit extends Model
{
    protected $table = 'dokumentasi_unit';
    protected $guarded = [];
    use HasFactory;

}
